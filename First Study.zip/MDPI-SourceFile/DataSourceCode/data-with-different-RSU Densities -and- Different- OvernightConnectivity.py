import xml.etree.ElementTree as ET
from math import sqrt
import random
import pandas as pd

def calc_xy_dist(x, y, refX, refY):
    return sqrt((x - refX)**2 + (y - refY)**2)

tree = ET.parse('dump.xml')
root = tree.getroot()
print("Parsing XML file completed.")

data = []
all_rsu_coords = [] 
rsu_values = 
rangeRSU =
percentageOvernight = 

for rsu_value in rsu_values:
    for range_rsu in rangeRSU:
        rsu_coords = all_rsu_coords[:rsu_value]

        vehicles = [0] * 100000
        vSign = [1.0 if random.random() < percentageOvernight else 0.0 for _ in range(100000)]
        reputcomm = [0] * 100000
        totalcomm = [0] * 100000
        onlinereputcomm = [0] * 100000

        for timestep in root.findall('timestep'):
            time = float(timestep.attrib["time"])

            if time % 300 < 0.01:
                count = sum(1 for v in vehicles if v != 0)
                presigns = sum(1 for v in vSign if v > 0.0)
                totC = sum(totalcomm)
                totRC = sum(reputcomm)
                totOAC = sum(onlinereputcomm)

                data.append({
                    'Time': time / 60,
                    'RSUs': rsu_value,
                    'RSURange': range_rsu,
                    'OvernightPercentage': percentageOvernight,
                    'TotalVehicles': count,
                    'Presignatures': presigns,
                    'TotalCommunications': totC,
                    'ReputableCommunications': totRC,
                    'OnlineAvailableCommunications': totOAC
                })

            for vehicle in timestep.findall('vehicle'):
                vID = int(vehicle.attrib["id"][3:])
                vehicles[vID] = 1
                x, y = float(vehicle.attrib["x"]), float(vehicle.attrib["y"])

                for rsuX, rsuY in rsu_coords:
                    if calc_xy_dist(x, y, rsuX, rsuY) < range_rsu:
                        vSign[vID] = 1.0

                for vehicle2 in timestep.findall('vehicle'):
                    if vehicle2.attrib["id"] != vehicle.attrib["id"]:
                        x2, y2 = float(vehicle2.attrib["x"]), float(vehicle2.attrib["y"])
                        if calc_xy_dist(x, y, x2, y2) < range_rsu:
                            totalcomm[vID] += 1
                            if vSign[vID] > 0.0:
                                reputcomm[vID] += 1
                            if any(calc_xy_dist(x, y, rsuX, rsuY) < range_rsu for rsuX, rsuY in rsu_coords):
                                onlinereputcomm[vID] += 1

df = pd.DataFrame(data)
if df.empty:
    print("No data collected. Check XML content and script logic.")
else:
    excel_filename = 
    df.to_excel(excel_filename, index=False)
    print(f"Data written to {excel_filename}")
